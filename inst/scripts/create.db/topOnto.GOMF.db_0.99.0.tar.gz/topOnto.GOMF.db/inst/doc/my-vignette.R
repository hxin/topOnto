## ----1,echo=FALSE,results='hide',message=FALSE---------------------------
library(topOnto.HDO.db)
help(topOnto.HDO.db)

## ------------------------------------------------------------------------
FirstTenBimap <- ONTTERM[1:10]
class(FirstTenBimap)
xx <- as.list(FirstTenBimap)
ID(xx[[2]])
Definition(xx[[2]])
Ontology(xx[[2]])
Term(xx[[2]])
Synonym(xx[[2]])
Secondary(xx[[2]])

## ------------------------------------------------------------------------
xx <- as.list(ONTANCESTOR)
xx <- xx[!is.na(xx)]
xx[1:4]

## ------------------------------------------------------------------------
xx <- as.list(ONTPARENTS)
xx <- xx[!is.na(xx)]
xx[1:4]

## ------------------------------------------------------------------------
xx <- as.list(ONTOFFSPRING)
xx <- xx[!is.na(xx)]
xx[1:4]

## ------------------------------------------------------------------------
xx <- as.list(ONTCHILDREN)
xx <- xx[!is.na(xx)]
xx[1:4]

## ------------------------------------------------------------------------
ONT_dbschema()

## ------------------------------------------------------------------------
ONTMAPCOUNTS

